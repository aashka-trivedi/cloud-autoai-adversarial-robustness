This directory contains the scored predictions of the model trained on gcp. The true label is the actual label of the image, while the confidence of label i is in colum label_i_score.
The actual predicted labels are in column 'Predicted_Labeles"
